package com.dummy;

import com.dummy.DummySerialPortEvent;

public interface DummySerialPortEventListener {
    public void serialEvent(final DummySerialPortEvent spe);
}
